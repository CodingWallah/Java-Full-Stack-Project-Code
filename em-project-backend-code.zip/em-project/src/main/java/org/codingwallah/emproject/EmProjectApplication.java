package org.codingwallah.emproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmProjectApplication.class, args);
	}

}
